


// This example was made for Node.JS

/*
    JSON KEYS MUST STAY THE SAME AS BELOW
*/

let axios = require('axios')
const mysql = require('mysql')
const con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "codenationgroup!4908",
  database: "fletchbanbase"
})
const express = require("express");
var bodyParser = require('body-parser')
var app = express()

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))

// parse application/json
app.use(bodyParser.json())
let path = require('path')
app.listen(1100)
let cors = require('cors')
var corsOptions = {
    origin: 'https://dash.fletchbot.xyz',
    optionsSuccessStatus: 200 // some legacy browsers (IE11, various SmartTVs) choke on 204
  }
app.use(cors(corsOptions))
app.get('/', (req, res) => {

res.sendFile(path.resolve('./src/index.html'))

})


app.get('/api/v1/firewall/:userid', async function(req, res) {
    res.set('Access-Control-Allow-Origin', '*');
    if(!req?.params?.userid) return res.redirect('/');
    req.params.userid = req.params.userid.replaceAll('`', '').replaceAll('"', '');
    await con.query(`SELECT * FROM bans WHERE userid="${req?.params?.userid}" AND active=true`, async (err, row) => {
        if(err) throw err;
        if(!row[0]) {
            // If the user is not banned
            let json_ = {
                "active": false, // This means that the user is not banned
            }
            return res.type('json').send(JSON.stringify(json_, null, 4) + '\n');
        } else {
            // If the user is banned
            let json_ = {
                "active": true,
                "userid": row[0].userid,
                "reason": row[0].reason,
                "proof": row[0].proof || 'None provided...',
                "time": row[0].timeofban
            }
            return res.type('json').send(JSON.stringify(json_, null, 4) + '\n');
        };
    });
});





app.get('/api/v1/bans/users/:userid', async function(req, res) {
    res.set('Access-Control-Allow-Origin', '*');
    if(!req?.params?.userid) return res.redirect('/');
    req.params.userid = req.params.userid.replaceAll('`', '').replaceAll('"', '');
    await con.query(`SELECT * FROM bans WHERE userid="${req?.params?.userid}" AND active=true`, async (err, row) => {
        if(err) throw err;
        if(!row[0]) {
            // If the user is not banned
            let json_ = {
                "active": false, // This means that the user is not banned
            }
            return res.type('json').send(JSON.stringify(json_, null, 4) + '\n');
        } else {
            // If the user is banned
            let json_ = {
                "active": true,
                "userid": row[0].userid,
                "reason": row[0].reason,
                "proof": row[0].proof || 'None provided...',
                "time": row[0].timeofban
            }
            return res.type('json').send(JSON.stringify(json_, null, 4) + '\n');
        };
    });
});

app.get('/api/v1/ping', (req, res) =>{
    res.set('Access-Control-Allow-Origin', '*');
    let json_ = {
        "ping": 200,
    }
    return res.type('json').send(JSON.stringify(json_, null, 4) + '\n');
})

app.post('/api/v1/removeban/', async function(req, res) {
    // Authorization
  if(!req.headers.auth === "tvnDsePjKX33WX") return res.type('json').send(JSON.stringify({status: 403, reason: "Unauthorized"}))
 
   if(!req.body.userid) return res.type('json').send(JSON.stringify({ status: 500, reason: "Missing userid"}, null, 4) + '\n')
  //  if(!req.body.banProof) return res.type('json').send(JSON.stringify({ status: 500, reason: "Missing banProof in request body" }, null, 4) + '\n');
                      // Message Builder
                    
  
 
//if(!row[0]) return res.type('json').send(JSON.stringify({ status: 500, reason: "User is not banned"}, nulll
    await con.query(`DELETE FROM bans WHERE active=true AND userid="${req.body.userid}"`, async (err, row) => {
        if(err) throw err;
    });
  
    return res.type('json').send(JSON.stringify({ status: 201, reason: "SUCCESS" }, null, 4) + '\n');
  
   
  });

  app.get('/legacy/number', async function(req, res) {
    let numberfile = require('./number.json')
    res.send(JSON.stringify({ number: numberfile.number}, null, 4) + '\n')
  })
app.post('/api/v1/postban/', async function(req, res) {
    // Authorization
let numberfile = require('./number.json')

  if(!req.headers.auth === "tvnDsePjKX33WX") return res.type('json').send(JSON.stringify({status: 403, reason: "Unauthorized"}))
    res.set("Access-Control-Allow-Origin", "*");
  //  if(!check) return res.type('json').send(JSON.stringify({ status: 403, reason: "Invalid API Token sent in request / doesn't exist." }, null, 4) + '\n');
  //  if(check.banned) return res.type('json').send(JSON.stringify({ status: 403, reason: "Your API token has been banned." }, null, 4) + '\n');
    // Make sure JSON keys are all here
    if(!req?.body?.userid) return res.type('json').send(JSON.stringify({ status: 500, reason: "Missing userid in request body" }, null, 4) + '\n');
    if(!req.body.reason) return res.type('json').send(JSON.stringify({ status: 500, reason: "Missing reason in request body" }, null, 4) + '\n');
    if(!req.body.proof) return res.type('json').send(JSON.stringify({ status: 500, reason: "Missing proof in request body" }, null, 4) + '\n');
    if(!req.body.time) return res.type('json').send(JSON.stringify({ status: 500, reason: "Missing time in request body" }, null, 4) + '\n');
  //  if(!req.body.banProof) return res.type('json').send(JSON.stringify({ status: 500, reason: "Missing banProof in request body" }, null, 4) + '\n');
                      // Message Builder
                    
  

async function run() {
    let request = await axios({
        method: 'post',
        url: 'https://firewall.hyperz.net/api/postban',
        headers: {
            Accept: 'application/json, text/plain, */*',
            'User-Agent': '*',
            'authorization': 'Mu3Jgx23SvNFbSYfN5s9ctNZ0lTJ7NpIpS'
        },
        data: {
            "userId": `${req.body.userid}`,
            "userTag": `ID: ${req.body.userid}`,
            "databaseName": "Fletch BanBase",
            "banReason": `${req.body.reason}`,
            "banProof": `${req.body.proof}`
        }
    })
 
    console.log(request.data)
}; 
    await con.query(`INSERT INTO bans (active, userid, reason, proof, timeofban, num) VALUES (true, "${req.body.userid}", "${req.body.reason}", "${req.body.proof}", "${req.body.time}", "${number}")`, async (err, row) => {
        if(err) throw err;
    });
  
    return res.type('json').send(JSON.stringify({ status: 201, reason: "SUCCESS" }, null, 4) + '\n');
  
   
  });
console.log('[SYSTEM]: https://banbase.fletchbot.xyz/ is online! ')
