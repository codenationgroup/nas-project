// Required modules
const express = require('express');
const multer = require('multer');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

const config = require('./config.json')
let productionvalue = config.prod
// Set up Express app
const app = express();
const port = config.port || 3000;
const FormData = require('form-data');
app.set('view engine', 'ejs');
// Set up multer to handle file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, './uploads');
  },
  filename: (req, file, cb) => {
    const fileName = `${Date.now()}_${file.originalname}`;
    cb(null, fileName);
  },
});
// realistic logging, I mean cmon who really likes to read console logs?

let output = ``
function buildOutput(dialogue, information, extra){
output = dialogue + '\n' + information + '\n' + extra + '\n'
fs.writeFileSync('./log.txt', output)
}


let localipmachaddr = []
const upload = multer({ storage });
function machinehandler(){
//Dynamic Machine Handler (LOCAL)
let machineportrange = {start: 1001, end: 1250}
let machineaddripv4range = {start: 1, end: 100}


 for(let num2 = machineaddripv4range.start; num2 <= machineaddripv4range.end; num2 ++){
for(let num = machineportrange.start; num <= machineportrange.end; num++){
let ipaddr = `http://192.168.86.${num2}`
let newaddr = ipaddr + `:${num}`
axios.get(newaddr).then(function (response){
  console.log(`Connected to ${newaddr}`)

 localipmachaddr.push(newaddr)
})
}
}
setTimeout(function(){ buildOutput(`It's abt time to update don't ya think?`, `[SERVER]: Updating machines!`, `[OUTPUT-END-LINE]: Updated. No idea if we made progress tbh.`); machinehandler()}, 5000)

} 

if(productionvalue === 'false'){
  machinehandler()
}else{
  localipmachaddr.push(`https://drive-two.codenationgroup.repl.co`)
}


// Set up a route for uploading files
app.post('/upload', upload.single('file'), async (req, res) => {
  // Get the file name and path
  const fileName = req.file.filename;
  const filePath = path.join(__dirname, 'uploads', fileName);

  // Select a random storage machine
  const storageMachines = localipmachaddr;
  if (!Array.isArray(storageMachines)) return res.status(500).send('Invalid configuration: machines must be an array');
  const randomIndex = Math.floor(Math.random() * storageMachines.length);
  const selectedMachine = storageMachines[randomIndex];

  // Upload the file to the selected machine
  const url = `${selectedMachine}/upload`;
  try {
    const formData = new FormData();
    formData.append('file', fs.createReadStream(filePath));
    const response = await axios({
      method: 'post',
      url,
      data: formData,
      headers: {
        'Content-Type': `multipart/form-data; boundary=${formData._boundary}`,
      },
    });
  } catch (error) {
    console.error(error);
  }

  res.redirect('/');
});


// Set up a route for downloading files
app.get('/download/:fileName', async (req, res) => {
  const fileName = req.params.fileName;
  const storageMachines = localipmachaddr
  let downloaded = false;
  for (const machine of storageMachines) {
    const url = `${machine}/storage/${fileName}`;
    const filePath = path.join(__dirname, 'downloads', fileName);
    try {
      const response = await axios({
        method: 'get',
        url,
        responseType: 'stream',
      });
      const fileStream = fs.createWriteStream(filePath);
      response.data.pipe(fileStream);
      response.data.on('end', () => {
        downloaded = true;
        res.download(filePath, fileName);
      });
    } catch (error) {
      console.error(error);
    }
    if (downloaded) {
      break;
    }
  }
  if (!downloaded) {
    res.send('File not found');
  }
});

// Set up a route for displaying files
app.get('/', async (req, res) => {
try{
  const files = await Promise.all(localipmachaddr.map(async (machine) => {
    const fileList = await getFileList(machine);
    return fileList.map(file => `${machine}/download/${file}`);
  }));

  const flattenedFiles = files.flat();
  res.render('index', { files: flattenedFiles, nolink: 'false' });
}catch{
  res.render('index', {files: ['Unable to connect to host machine'], nolink: 'true'})
}
});

  
async function getFileList(machine) {
  try {
    const response = await axios.get(`${machine}/storage`);
    const files = response.data;
    if (!Array.isArray(files)) {
      console.log(`Invalid response format: ${JSON.stringify(response.data)}`);
    files = 'Unable to connect to storage machines, check back later.'
      return files;
    }
    return files;
  } catch (error) {
    console.log(machine)
    let files = 'Unable to connect to storage machines, check back later.'
   
   console.log('[SYSTEM]: Unable to connect')
   return files;
  }
}



  
  // Set up server to listen on specified port
  app.listen(port, () => {
  console.log(`Server is running on port ${port}`)
  })

  process.on('unhandledRejection', () =>{
    
  })